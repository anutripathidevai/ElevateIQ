import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import type { AdaptiveScorecard } from "../types";

function band(score: number): {
  label: string;
  variant: "success" | "warning" | "danger";
} {
  if (score >= 82) return { label: "Strong", variant: "success" };
  if (score >= 68) return { label: "Solid", variant: "success" };
  if (score >= 52) return { label: "Borderline", variant: "warning" };
  return { label: "Needs work", variant: "danger" };
}

function ScoreBar({ score }: { score: number | null }) {
  const pct = score === null ? 0 : Math.max(0, Math.min(100, score));
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
      <div
        className="h-full rounded-full bg-primary"
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

/** Renders the final adaptive-interview scorecard. Score scale is 0-100. */
export function AdaptiveScorecardView({
  scorecard,
}: {
  scorecard: AdaptiveScorecard;
}) {
  const overall = band(scorecard.overallScore);
  return (
    <div className="space-y-6">
      {!scorecard.aiGenerated && (
        <p className="rounded-md border border-warning/30 bg-warning/5 px-3 py-2 text-sm text-muted-foreground">
          This is a <strong>heuristic estimate</strong> generated without AI. It
          reflects concept coverage and answer depth, not a full qualitative
          assessment. Configure Azure OpenAI for AI-graded evaluations.
        </p>
      )}

      {/* Overall */}
      <section className="rounded-xl border border-border bg-card p-5">
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-lg font-semibold">Overall readiness</h2>
          <Badge variant={overall.variant}>{overall.label}</Badge>
        </div>
        <div className="mt-3 flex items-baseline gap-2">
          <span className="text-3xl font-bold tabular-nums">
            {scorecard.overallScore}
          </span>
          <span className="text-sm text-muted-foreground">/ 100</span>
          <span className="ml-auto text-xs text-muted-foreground">
            Confidence {Math.round(scorecard.confidence * 100)}%
          </span>
        </div>
        <div className="mt-3">
          <ScoreBar score={scorecard.overallScore} />
        </div>
      </section>

      {/* Competency scores */}
      <section className="rounded-xl border border-border bg-card p-5">
        <h2 className="text-lg font-semibold">Scores by competency</h2>
        <ul className="mt-4 space-y-4">
          {scorecard.competencyScores.map((c) => (
            <li key={c.competencyId}>
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium">{c.name}</span>
                <span className="tabular-nums text-muted-foreground">
                  {c.score === null ? "—" : `${c.score} / 100`}
                </span>
              </div>
              <div className="mt-1.5">
                <ScoreBar score={c.score} />
              </div>
              {c.score === null ? (
                <p className="mt-1.5 text-xs text-muted-foreground">
                  Not assessed during this interview.
                </p>
              ) : (
                <>
                  {c.evidence.length > 0 && (
                    <ul className="mt-1.5 space-y-0.5">
                      {c.evidence.map((e, i) => (
                        <li
                          key={i}
                          className="flex gap-1.5 text-xs text-muted-foreground"
                        >
                          <span aria-hidden className="text-success">
                            ✓
                          </span>
                          <span>{e}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                  {c.gaps.length > 0 && (
                    <ul className="mt-1 space-y-0.5">
                      {c.gaps.map((g, i) => (
                        <li
                          key={i}
                          className="flex gap-1.5 text-xs text-muted-foreground"
                        >
                          <span aria-hidden className="text-warning">
                            →
                          </span>
                          <span>{g}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </>
              )}
            </li>
          ))}
        </ul>
      </section>

      {/* Strengths & weaknesses */}
      <div className="grid gap-4 sm:grid-cols-2">
        <section className="rounded-xl border border-border bg-card p-5">
          <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Strengths
          </h3>
          {scorecard.strengths.length > 0 ? (
            <ul className="mt-3 space-y-1.5 text-sm">
              {scorecard.strengths.map((s, i) => (
                <li key={i} className="flex gap-1.5">
                  <span aria-hidden className="text-success">
                    +
                  </span>
                  <span>{s}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-3 text-sm text-muted-foreground">
              No standout strengths yet — keep practicing to build them.
            </p>
          )}
        </section>

        <section className="rounded-xl border border-border bg-card p-5">
          <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Focus areas
          </h3>
          {scorecard.weaknesses.length > 0 ? (
            <ul className="mt-3 space-y-1.5 text-sm">
              {scorecard.weaknesses.map((s, i) => (
                <li key={i} className="flex gap-1.5">
                  <span aria-hidden className="text-warning">
                    →
                  </span>
                  <span>{s}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-3 text-sm text-muted-foreground">
              Strong across the board — nice work.
            </p>
          )}
        </section>
      </div>

      {/* Recommended learning */}
      {scorecard.recommendedTopics.length > 0 && (
        <section className="rounded-xl border border-border bg-card p-5">
          <h2 className="text-lg font-semibold">Recommended learning</h2>
          <ol className="mt-4 space-y-3">
            {scorecard.recommendedTopics.map((t, i) => (
              <li key={t.competencyId} className="flex gap-3">
                <span
                  aria-hidden
                  className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary"
                >
                  {i + 1}
                </span>
                <div>
                  <p className="text-sm font-medium">
                    {t.href ? (
                      <Link
                        href={t.href}
                        className="text-primary underline-offset-2 hover:underline"
                      >
                        {t.topic}
                      </Link>
                    ) : (
                      t.topic
                    )}
                  </p>
                  <p className="text-sm text-muted-foreground">{t.reason}</p>
                </div>
              </li>
            ))}
          </ol>
        </section>
      )}
    </div>
  );
}
